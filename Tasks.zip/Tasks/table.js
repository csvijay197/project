var items = [];
var btnValue = "insert";
var indexValue;

var searchRes =[];

function addItem(){
    let name=document.getElementById("name").value;
    let category =document.getElementById("category").value;
    let year = document.getElementById("year").value;
   
    if(name==''&& category=='' && year==''){
        alert("Please Enter Required Fields");
        return;
    }

    if(name ==''){
        alert("Please Enter the Name field");
        return;
    }

    if(category==''){
        alert("Please Enter the Category field");
        return;
    }
    
    if(year ==''){
        alert("Please Enter the Year field");
        return;
    }
    
    if(btnValue == "insert"){
        const itemObj ={
            name : name,
            category :category,
            year : year
        }
    
        items.push(itemObj);
    }else{
        console.log("else. . ");
        console.log(indexValue);

       console.log(items[indexValue]) 
        items[indexValue].name= document.getElementById("name").value;
        items[indexValue].category =document.getElementById("category").value;
        items[indexValue].year = document.getElementById("year").value ;

        btnValue="insert";


    }
   

    // console.log(items);

    // alert("Insertion Succesfull");

    document.getElementById("name").value='';
    document.getElementById("category").value='';
    document.getElementById("year").value='';

    updateTable();
    
    }


function updateTable(){

    let tbody = document.getElementById("table-body");
    tbody.innerHTML='';

    for (let index = 0; index < items.length; index++) {
        const element = items[index];
        // console.log(element);
         let row = `<tr>
                    <td> ${index+1} </td>
                    <td> ${items[index].name}</td>
                    <td> ${items[index].category}</td>
                    <td> ${items[index].year}</td>
                    <td><button class ="button-edit" onclick="editItem(${index})">Edit</button></td>
                    <td><button class ="button-delete" onclick="deleteItem(${index})">Delete</button></td>
                </tr>`
        // console.log(row);
        tbody.innerHTML += row;
    }
}



function deleteItem(index){

    items.splice(index,1);
    updateTable();

}

function editItem(index) {

    let item = items[index];

    document.getElementById("name").value = item.name;
    document.getElementById("category").value = item.category;
    document.getElementById("year").value = item.year;

    btnValue = "update";

    indexValue = index;
    
}


// function editItem(index) {

//     let item = items[index];

//     document.getElementById("name").value = item.name;
//     document.getElementById("category").value = item.category;
//     document.getElementById("year").value = item.year;

//     const addButton = document.querySelector("button[onclick='addItem()']");
//     addButton.innerText = "Save";
//     addButton.onclick = function () {
//         saveChanges(index);
//     };
// }

// function saveChanges(index) {

//     let name = document.getElementById("name").value;
//     let category = document.getElementById("category").value;
//     let year = document.getElementById("year").value;

//     if (name == '' && category == '' &&  year == '') {
//         alert("Please fill the required fields");
//         return;
//     }

//     let updatedItems = {  name , 
//                         category ,
//                         year
//                     }

//     items[index] = updatedItems;

//     document.getElementById("name").value = '';
//     document.getElementById("category").value = '';
//     document.getElementById("year").value = '';

//     const addButton = document.querySelector("button[onclick]");
//     addButton.innerText = "Add Item";
//     addButton.onclick = addItem;

//     updateTable();
// }


function searchFun() {
    let searchValue = document.getElementById("search").value.toLowerCase(); 
    searchRes = [];                     
    for (let index = 0; index < items.length; index++) {
        if (items[index].name.toLowerCase().includes(searchValue)) {
            searchRes.push(items[index]); 
        }
        searchTable(); 
    }

console.log(searchRes);

function searchTable() {
    let tbody = document.getElementById("table-body");
    tbody.innerHTML = ''; 

    if (searchRes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No data found.</td></tr>'; 
        return; 
    }

    for (let index = 0; index < searchRes.length; index++) {
        const element = searchRes[index];
        let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${element.name}</td>
                    <td>${element.category}</td>
                    <td>${element.year}</td>
                    <td><button class ="button-edit" onclick="editItem(${index})">Edit</button></td>
                    <td><button class ="button-delete" onclick="deleteItem(${index})">Delete</button></td>
                </tr>`;
        tbody.innerHTML += row; 
    }
}
}


let isAscending = true; 

function sortName() {
  items.sort((a, b) => {
    if (isAscending) {
      return a.name.localeCompare(b.name); 
    } else {
      return b.name.localeCompare(a.name); 
    }
  });
  isAscending = !isAscending;

  sortFunc();
}


function sortCategory(){
    items.sort((a, b) => {
        if (isAscending) {
          return a.category.localeCompare(b.category); 
        } else {
          return b.category.localeCompare(a.category); 
        }
      });
      
      isAscending = !isAscending;
      sortFunc();
}

function sortYear(){
    items.sort((a, b) => {
        if (isAscending) {
          return a.year.localeCompare(b.year); 
        } else {
          return b.year.localeCompare(a.year); 
        }
      });

      isAscending = !isAscending;
      
      sortFunc();
}


function sortFunc() {
    let tbody = document.getElementById("table-body");
    tbody.innerHTML = ''; 


    for (let index = 0; index < items.length; index++) {
        const element = items[index];
        let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${element.name}</td>
                    <td>${element.category}</td>
                    <td>${element.year}</td>
                    <td><button class ="button-edit" onclick="editItem(${index})">Edit</button></td>
                    <td><button class ="button-delete" onclick="deleteItem(${index})">Delete</button></td>
                </tr>`;
        tbody.innerHTML += row; 
    }
}



  function validYearFun() {

    let validYear = document.getElementById("year").value;

    let currentYear = new Date().getFullYear();

    if (validYear.trim() === "" || validYear.length < 4) {
        return true; 
      }

    if ( !/^\d{4}$/.test(validYear) ||  validYear < 1947 || validYear > currentYear){
        alert("Enter valid year between 1947  & " + currentYear);
        document.getElementById("year").value='';
        return false ;
    }
    return true;
  }